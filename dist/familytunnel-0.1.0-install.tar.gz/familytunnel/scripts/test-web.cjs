// Exercise the actual browser callbacks without a browser or a live LAN.
const {readFileSync}=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
class Element {
  constructor(){this.children=[];this.hidden=true;this.value='';this.textContent='';}
  append(...items){this.children.push(...items);}
  replaceChildren(...items){this.children=items;}
  scrollIntoView(){this.scrolled=true;}
  focus(){this.focused=true;}
}
const elements=new Map(),storage=new Map(),calls=[];
let failTest=false,existing=[];
const context=vm.createContext({
  URL,
  document:{getElementById(id){if(!elements.has(id))elements.set(id,new Element());return elements.get(id)},createElement(){return new Element()}},
  localStorage:{getItem:key=>storage.get(key),setItem:(key,value)=>storage.set(key,value),removeItem:key=>storage.delete(key)},
  setInterval(){},confirm(){return true},
  fetch:async(path,options)=>{
    calls.push({path,options});
    if(path==='/api/session')return {ok:false,status:401,text:async()=>JSON.stringify({error:'login'})};
    if(path==='/api/backend-test')return {ok:!failTest,status:failTest?503:200,text:async()=>JSON.stringify(failTest?{error:'Testfehler'}:{reachable:true,message:'Vom CT erreichbar (TCP).'})};
    if(path==='/api/routes'&&options.method==='GET')return {ok:true,text:async()=>JSON.stringify(existing)};
    if(path.startsWith('/api/routes')&&['POST','PUT'].includes(options.method)) {
      const route=JSON.parse(options.body);
      route.id=options.method==='POST'?Math.max(0,...existing.map(item=>item.id))+1:Number(path.split('/').at(-1));
      existing=existing.filter(item=>item.id!==route.id).concat(route);
      return {ok:true,status:202,text:async()=>JSON.stringify({ok:true,routes:existing,sync_pending:true,message:'Gespeichert. Übertragung läuft.'})};
    }
    return {ok:true,text:async()=>JSON.stringify({ok:true})};
  }
});
vm.runInContext(readFileSync('internal/app/web/app.js','utf8'),context);
async function run(){
  await new Promise(resolve=>setImmediate(resolve));
  const data={domain:'test.example.net',services:[{name:'Dienst',backend:'http://192.168.1.30:80'}]};
  context.input=data;
  vm.runInContext('renderDiscovery(input)',context);
  const card=elements.get('discovered').children[0],result=card.children[3],actions=card.children[4];
  await actions.children[0].onclick();
  assert.match(result.textContent,/Vom CT erreichbar/);
  assert.equal(calls.filter(call=>call.path==='/api/backend-test').length,1);
  context.savedRoutes=[{id:1,domain:data.domain,backend:data.services[0].backend,enabled:true}];
  vm.runInContext('renderRoutes(savedRoutes)',context);
  const savedRow=elements.get('routes').children[0];
  await savedRow.children[3].children[2].onclick();
  assert.match(savedRow.children[2].textContent,/Erreichbar/);
  const tests=calls.filter(call=>call.path==='/api/backend-test');
  assert.equal(tests.length,2);
  assert.equal(tests[0].options.body,tests[1].options.body,'Both lists must run the same test');
  failTest=true;
  await actions.children[0].onclick();
  assert.match(result.textContent,/Testfehler/);
  assert.equal(actions.children[0].disabled,false);
  assert.equal(actions.children[0].textContent,'Erneut testen');
  existing=[{id:7,domain:'test.example.net',backend:'http://192.168.1.40:80'}];
  await actions.children[2].onclick();
  assert.ok(calls.some(call=>call.path==='/api/routes/7'&&call.options.method==='PUT'));
  assert.equal(JSON.parse(storage.get('ft-last-discovery')).services.length,0);
  const multiple={domain:'test.example.net',services:[{name:'Media',backend:'http://192.168.1.30:8096',port:8096},{name:'Home',backend:'http://192.168.1.40:8123',port:8123}]};
  context.input=multiple;
  vm.runInContext('renderDiscovery(input)',context);
  const multiCards=elements.get('discovered').children;
  assert.equal(Number(multiCards[0].children[2].children[2].value),8096);
  assert.equal(Number(multiCards[1].children[2].children[2].value),8123);
  assert.match(multiCards[0].children[2].children[3].textContent,/:8096\//);
  existing=[{id:7,domain:'test.example.net',backend:'http://192.168.1.40:80',public_port:443}];
  await multiCards[0].children[4].children[2].onclick();
  const publishes=calls.filter(call=>call.path==='/api/routes'&&call.options.method==='POST');
  assert.equal(JSON.parse(publishes.at(-1).options.body).public_port,8096,'New port must create a new route, not replace root');
  vm.runInContext('renderDiscovery(input)',context);
  await elements.get('discovered').children[0].children[4].children[1].onclick();
  assert.equal(JSON.parse(calls.filter(call=>call.path==='/api/public-test').at(-1).options.body).public_port,8123);
  const editor=elements.get('routeForm');
  editor.elements=Object.fromEntries(['id','domain','backend','public_port','enabled'].map(key=>[key,new Element()]));
  editor.reset=()=>{for(const field of Object.values(editor.elements)){field.value='';field.checked=false}};
  context.savedRoutes=[{id:25,domain:'edit.example.net',backend:'http://192.168.1.2:8096',public_port:8096,enabled:true}];
  vm.runInContext('renderRoutes(savedRoutes)',context);
  await elements.get('routes').children[0].children[3].children[0].onclick();
  assert.equal(elements.get('routeEditor').open,true,'Editing must open the collapsed editor');
  assert.equal(editor.elements.domain.focused,true);
  assert.equal(editor.elements.id.value,25);
  editor.elements.domain.value='edited.example.net';
  editor.elements.public_port.value='';
  const saveButton=new Element(),beforeSave=calls.length;
  await editor.onsubmit({preventDefault(){},submitter:saveButton,target:editor});
  const write=calls.slice(beforeSave).find(call=>call.options.method==='PUT');
  assert.equal(write.path,'/api/routes/25');
  assert.equal(JSON.parse(write.options.body).public_port,443,'Empty port defaults to 443');
  assert.equal(calls.slice(beforeSave).length,1,'Saving must render response without waiting for status/logs/stats or another GET');
  assert.ok(elements.get('routes').children.some(row=>row.children[0].children[0].href==='https://edited.example.net/'));
  editor.elements.id.value='';editor.elements.domain.value='manual.example.net';editor.elements.backend.value='http://192.168.1.3:8080';editor.elements.public_port.value='';editor.elements.enabled.checked=true;
  const beforeCreate=calls.length;
  await editor.onsubmit({preventDefault(){},submitter:saveButton,target:editor});
  assert.equal(calls.length-beforeCreate,1);
  assert.equal(calls.at(-1).options.method,'POST');
  assert.equal(JSON.parse(calls.at(-1).options.body).public_port,443);
  assert.equal(saveButton.disabled,false);
  assert.ok(elements.get('routes').children.some(row=>row.children[0].children[0].href==='https://manual.example.net/'));
  assert.ok(calls.every(call=>call.path.startsWith('/api/')),'No direct browser request to a LAN backend');
  console.log('Web callbacks: CT test, inline errors and existing-domain publication passed.');
}
run().catch(error=>{console.error(error);process.exitCode=1});
